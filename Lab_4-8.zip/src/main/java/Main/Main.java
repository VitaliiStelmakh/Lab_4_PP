package Main;
import PlayRoom.PlayRoomMenu;
import Toy.Toy;

public class Main {
    public static void main(String[] args) {
        PlayRoomMenu pr = new PlayRoomMenu();
        pr.execute();
    }
}
